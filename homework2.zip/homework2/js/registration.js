/*
Author: Ted nesham
Date: 09/30/2019
*/

function checkRequiredFields() {
/*************************************
 a function that will check each field for valid input and
 return true or false if the fields are all populated
 and have correct inputs.
**************************************/
    var didFindBlank = true;
    fname = document.getElementById('Fname').value;
    lname = document.getElementById('Lname').value;
    email = document.getElementById('Email').value;
    cemail = document.getElementById('cEmail').value;
    uname = document.getElementById('Username').value;
    passw = document.getElementById('Password').value;
    cpassw = document.getElementById('CPassword').value;
    phone = document.getElementById('PhoneNum').value;
    // local variables used to check for required fields.

    var checkName = ( function() {
        if (fname.search(/^[A-Z]+[a-z]*[^[0-9A-Z]$/) < 0) {
            //Check that the named order otherwise alert the user that it's incorrect.
            alert("Make sure the first letter of your first name is capitalized ");
        }
        else {
            return true;
        }
     }());
    var checkLName = ( function() {
         // check that the last name has starts with upper and ends with lower no numbers.
         if (lname.search(/^[A-Z]+[a-z]*[^[0-9A-Z]$/) < 0) {
             alert("Make sure the first letter of your last name is capitalized ");
         }
         else {
             return true;
         }
     }());
    var checkPass = ( function() {
         if (cpassw === passw ) {
             console.log("passwords match checking validity.");
             // since both passwords are a match then we can justify only checking one
             if (passw.search(/^[A-Z][a-z0-9]{6}[0-9]{1}$/) < 0) {
                 alert("The password you entered was invalid use the form: P4ssw0r6");
             }
             else return true;

         }
         else {
             alert("Please check that your passwords match.");
             return false;
         }
     })();
    var checkEmail = (function() {
         if (cemail === email) {
                return true;
         }
         else {
             return false;
         }

     })();
    var checkPhone = (function() {
         if (phone.length > 0) {
             // check if the phone number is currently there
             if (phone.search(/^[0-9]{3}(?:-|)[0-9]{3}(?:-|)[0-9]{4}$/) >= 0 ) {
                 return true;
             }
             else {
                 return false;
             }
         }
     })();
    var checkUname = (function () {
         if (uname.search(/^[a-zA-Z][a-z0-9]+$/) >= 0) {
             return true;

         }
         else {
             alert("Username is invalid: Please use the form user1... no numbers to start.")
             return false;
         }

     })();
     // end of checking all fields for proper input.

     if (checkName && checkPass && checkEmail && checkLName && checkPhone && checkUname) {
         //if every field has a correct value and is populated, the function returns true. else false.
         return true;
     }
     else {
         alert("* fields are required!");
         return false;
     }
}
